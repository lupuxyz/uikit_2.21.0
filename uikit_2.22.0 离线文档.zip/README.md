# UIkit

UIkit 2.22.0 中文文档翻译项目

##TODO  
  

###开始使用
  
documentation_project-structure.html  
documentation_less-sass.html  
documentation_create-a-theme.html  
documentation_create-a-style.html	 
documentation_customizer-json.html  
documentation_javascript.html	 
documentation_custom-prefix.html	 
  
###核心组件
  
ALL DONE  
  
##附加组件
  
components.html	
  
grid-js.html	 
  
dotnav.html	 
slidenav.html	 
pagination-js.html	 
  
form-advanced.html	 
form-file.html	 
form-password.html	 
form-select.html	
placeholder.html	 
progress.html	 
  
lightbox.html	 
autocomplete.html	 
datepicker.html	 
htmleditor.html	 
slider.html	 
slideset.html	 
slideshow.html	 
parallax.html	 
accordion.html	 
notify.html	 
search.html	 
nestable.html	 
sortable.html	 
sticky.html	 
timepicker.html	 
tooltip.html	 
upload.html	 
  
###定制工具
  
customizer.html	   

###布局示例
[不需要翻译]  
  
layouts_blog.html	 
layouts_contact.html	 
layouts_documentation.html	 
layouts_frontpage.html	 
layouts_login.html	 
layouts_portfolio.html	 
layouts_post.html	 
  
##DONE  
  
documentation_get-started.html  @yunye  V  
documentation_how-to-customize.html  @yunye  V  
documentation_layouts.html  @yunye  V  
  
   
  
core.html  @yunye  V  
base.html	 @yunye  V  
print.html	 @yunye  V  
grid.html	 @yunye  V  
panel.html	 @yunye  V  
index.html @yunye latest  V  
block.html	 @yunye  V  
article.html	 @yunye  V  
comment.html	 @yunye  V  
utility.html	@yunye  V  
flex.html	 @yunye  V  
cover.html	 @yunye  V  
  
nav.html	 @yunye  V  
  
button.html @李凯 2.21.0  
list.html @Ccc 2.21.0  
form.html @Ccc 2.21.0  
navbar.html	 @yunye  V  
subnav.html	 @yunye  V  
breadcrumb.html	 @yunye  V  
pagination.html	 @yunye  V  
tab.html	 @yunye  V  
thumbnav.html	 @yunye  V  
  
description-list.html @yunye  V  
table.html @yunye  V  
  
icon.html @yunye  V  	 
close.html	 @yunye  V  
badge.html	 @yunye  V  
alert.html	 @yunye  V  
thumbnail.html	 @yunye  V  
overlay.html	 @yunye  V  
text.html	 @yunye  V  
animation.html	@yunye  V   
contrast.html	 @yunye  V  
  
dropdown.html	 @yunye  V  
modal.html	 @yunye  V  
offcanvas.html	 @yunye  V  
switcher.html	 @yunye  V  
toggle.html	 @yunye  V  
scrollspy.html	 @yunye  V  
smooth-scroll.html	@yunye  V  

components.html	v  
  
grid-js.html	 v  
  
dotnav.html	 v  
slidenav.html	 v  
pagination-js.html	 v  
  
form-advanced.html	 v  
form-file.html	 v  
form-password.html	 v  
## Browser Support

![Chrome](https://raw.github.com/alrra/browser-logos/master/chrome/chrome_48x48.png) | ![Firefox](https://raw.github.com/alrra/browser-logos/master/firefox/firefox_48x48.png) | ![IE](https://raw.github.com/alrra/browser-logos/master/internet-explorer/internet-explorer_48x48.png) | ![Safari](https://raw.github.com/alrra/browser-logos/master/safari/safari_48x48.png) | ![Opera](https://raw.github.com/alrra/browser-logos/master/opera/opera_48x48.png)
--- | --- | --- | --- | --- |
Latest ✔ | Latest ✔ | 9+ ✔ | 7.1+ ✔ | Latest ✔ |

## Copyright and License

Copyright [YOOtheme](http://www.yootheme.com) GmbH under the [MIT license](LICENSE.md).
